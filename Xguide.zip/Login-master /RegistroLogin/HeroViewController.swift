//
//  HeroViewController.swift
//  RegistroLogin
//
//  Created by Angel de Jesus Robles Paloblanco on 5/15/20.
//  Copyright © 2020 Angel de Jesus Robles Paloblanco. All rights reserved.
//

import UIKit
class HeroViewController: UIViewController {

    @IBOutlet weak var attributeLbl: UITextView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titulolbl: UITextView!
    var hero:HeroStats?
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLbl.text = hero?.localized_name
        attributeLbl.text = hero?.Contenido
        titulolbl.text = hero?.Titulo
        let urlString = "https://topicosavanzados10.000webhostapp.com"+(hero?.Imagen)!
        let url = URL(string: urlString)
        imageView.downloaded(from: url!)
        
       
    }
}

