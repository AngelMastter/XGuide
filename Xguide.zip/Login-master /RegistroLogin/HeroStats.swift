//
//  HeroStats.swift
//  RegistroLogin
//
//  Created by Angel de Jesus Robles Paloblanco on 5/15/20.
//  Copyright © 2020 Angel de Jesus Robles Paloblanco. All rights reserved.
//

import Foundation

struct     HeroStats:Decodable {
    
    let localized_name : String
    let Titulo: String
    let Contenido : String
    let Imagen: String
    
    
}
