//
//  Funciones.swift
//  RegistroLogin
//
//  Created by Miguel Angel Jimenez Melendez on 3/10/20.
//  Copyright © 2020 Miguel Angel Jimenez Melendez. All rights reserved.
//

import Foundation
class function {
    
    func alerta(title: String, message: String) {
        let alert = UIALertController
    }
}
